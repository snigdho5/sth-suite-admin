<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Api extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        //$this->load->library('session');
    }

    public function onGetLeadDetails()
    {
        $jsonData = $this->input->post('oAuth_json');
        $json_Param = $this->input->post('jsonParam');
        //print_obj($this->input->post());

        if (!empty($jsonData)) {
            $decoded = json_decode($jsonData);
            $decodedParam = json_decode($json_Param);
            //print_obj($decodedParam);

            if ($decoded != '' || $decoded != NULL) {
                $sKey = $decoded->sKey;
                $aKey = $decoded->aKey;

                if ($sKey == secretKey && $aKey == accesskey) {

                    if (!empty($decodedParam)) {
                        $param = array(
                            'lead_email_c' => $decodedParam->lead_email
                        );
                        $getData = $this->smm->getLCstmData($select = 'leads_cstm.*', $param, $order_by = 'leads_cstm.owner_c', $order = 'ASC', $many = FALSE);
                    } else {
                       // $getData = $this->smm->getLCstmData();
                    }

                    //print_obj($getData);die;

                    if (!empty($getData)) {
                        // foreach ($getData as $key => $value) {
                            $return['leadData'] = array(
                                'lead_id'  => $getData->id_c,
                                'lead_email'  => $getData->lead_email_c
                            );
                        // }
                        $return['success'] = '1';
                    } else {
                        $return['leadData'] = '';
                        $return['success'] = '0';
                    }
                } else {
                    $return['success'] = '0';
                    $return['error'] = 'Credentials mismatch!';
                }
            } else {
                $return['success'] = '0';
                $return['error'] = 'JSON data error';
            }
        } else {
            $return['success'] = '0';
            $return['error'] = 'JSON data is empty';
        }

        header('Content-Type: application/json');
        echo json_encode($return);
    }
}
