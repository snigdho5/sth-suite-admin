<!-- All Required js -->
<!-- ============================================================== -->
<script src="<?php echo base_url().'common/assets/libs/jquery/dist/jquery.min.js';?>"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo base_url().'common/assets/libs/popper.js/dist/umd/popper.min.js';?>"></script>
<script src="<?php echo base_url().'common/assets/libs/bootstrap/dist/js/bootstrap.min.js';?>"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="<?php echo base_url().'common/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js';?>"></script>
<script src="<?php echo base_url().'common/assets/extra-libs/sparkline/sparkline.js';?>"></script>
<!--Wave Effects -->
<script src="<?php echo base_url().'common/dist/js/waves.js';?>"></script>
<!--Menu sidebar -->
<script src="<?php echo base_url().'common/dist/js/sidebarmenu.js';?>"></script>
<!--Custom JavaScript -->
<script src="<?php echo base_url().'common/dist/js/custom.min.js';?>"></script>
